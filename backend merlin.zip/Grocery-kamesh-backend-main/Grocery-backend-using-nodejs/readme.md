<img src="https://user-images.githubusercontent.com/73666943/206369188-28ff03cb-1636-4bb3-a338-7c9486f3f2fc.png" width="200" height="60" />

# Backend App

GroRents is a web platform for rentals & grocery which connects property owners with tenants and buyers directly, thereby making buying, selling, and renting of properties simpler, convenient and affordable.

Backend built using modern technologies: Node.js, Express, MongoDB, Mongoose and Friends 😁
<br>
